MOHAMMAD IDREES AHMADI — PROFESSIONAL WEBSITE

Contents: index.html (self-contained bilingual English/Dari website, including the portrait supplied by the owner).

Privacy choices in this edition:
- No family, relationship, health, financial, or workplace-dispute details.
- No exact location, personal phone number, or private account links.
- No unverified awards, credentials, or claims of superiority.
- Portrait embedded from the image supplied by the owner; no face alteration was applied.

To preview: open index.html in a modern browser.
To publish: upload index.html to a static hosting provider after reviewing every public statement. This package does not itself create a public website URL.
